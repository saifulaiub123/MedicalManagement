﻿namespace MH.Application.Response
{
    public class AuthResponse
    {
        public List<string> Errors { get; set; }
    }
}
