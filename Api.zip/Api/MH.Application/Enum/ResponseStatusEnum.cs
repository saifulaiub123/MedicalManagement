﻿namespace MH.Application.Enum
{
    public enum ResponseStatus
    {
        OK = 1,
        FAILED = 0
    }
}
