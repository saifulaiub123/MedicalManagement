﻿

namespace MH.Application.Enum
{
    public enum RoleEnum
    {
        Admin = 1,
        Doctor = 2,
    }
}
