﻿namespace MH.Application.Enum
{
    public enum UserStatus
    {
        Active = 1,
        Pending = 2,
        Inactive = 3,
        Blocked = 4
    }
}
