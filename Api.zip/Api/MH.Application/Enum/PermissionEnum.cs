﻿
namespace MH.Application.Enum
{
    public enum PermissionEnum
    {
        Read = 1,
        Modify
    }
}
