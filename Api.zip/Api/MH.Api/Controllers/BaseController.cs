﻿using Microsoft.AspNetCore.Mvc;

namespace MH.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BaseController : ControllerBase
    {
    }
}
