﻿namespace MH.Domain.Constant
{
    public class DbDataType
    {
        public const string DateTime = "datetime";
        public const string Date = "date";
        public const string Xml = "xml";
    }
}
