﻿namespace MH.Domain.Constant
{
    public class ClaimConstant
    {
        public static string Id = "Id";
        public static string UserName = "Username";
        public static string Name = "Name";
        public static string FirstName = "FirstName";
        public static string LastName = "LastName";
        public static string SurName = "SurName";
        public static string Email = "Email";
        public static string UserRole = "UserRole";
    }
}
