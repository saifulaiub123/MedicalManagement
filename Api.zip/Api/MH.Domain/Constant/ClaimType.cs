﻿

namespace MH.Domain.Constant
{
    public static class ClaimType
    {
        public const string Id = "Id";
        public const string UserName = "UserName";
        public const string Name = "Name";
        public const string SurName = "SurName";
        public const string Email = "Email";
    }
}
