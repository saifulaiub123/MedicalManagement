﻿

namespace MH.Domain.Constant
{
    public static class ActionModeConst
    {
        public static string View = "view";
        public static string Edit = "edit";
    }
}
