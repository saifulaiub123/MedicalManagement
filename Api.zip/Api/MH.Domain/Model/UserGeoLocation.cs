﻿namespace MH.Domain.Model
{
    public class UserGeoLocation
    {
        public double Longitude { get; set; }
        public double Latitude { get; set; }
    }
}
